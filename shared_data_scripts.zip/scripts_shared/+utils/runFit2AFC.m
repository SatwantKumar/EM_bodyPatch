function [data, data2, xdata, ydata, x, snrf, results] = runFit2AFC(param, t1, i1)
if isfield(param, 'CellIndexGBFB')
    param.CellIndex{1} = param.CellIndexGBFB{i1};
end;
for i1 = 1:numel(param.CellIndex)
    [ Bstruct{i1}, condition{i1}, uNoiseLvls{i1} ] = analysisBehavDataStim( param, i1 );
end;

searchStrAnim = {'humanbodies'; 'monkeybodies';'humanfaces';'animate'};%[param.testType];
searchStrNonbod = {'humanobjects';'monkeyobjects';'humanfobjects';'objects'};%[param.testType];
for i1 = 1:numel(param.CellIndex)
    iter = 1;
    for b1 = 1:numel(Bstruct{i1})
        for c1 = 1:numel(Bstruct{i1}{b1}.Cond)
            if ~isempty(Bstruct{i1}{b1}.Cond{c1}.conditionName)
                conditionNames{i1}{iter} = Bstruct{i1}{b1}.Cond{c1}.conditionName{1};
                tmp = strsplit(conditionNames{i1}{iter},'_');
                conditionNamesU{i1}{iter} = tmp{1};
                iter = iter + 1;
            end;
        end;
        if ~isempty(Bstruct{i1})
            
        end;
    end;
end;
% for i1 = 1:numel(conditionNamesU)
%     for j1 = 1:4
%         [strc(j1,:)]= strcmp(unique(conditionNamesU{i1}), searchStrAnim{j1});
%     end;
%     indx(i1,:) = sum(strc,2);
% end;
% indx(19:22,:) = [0 0 0 1;0 0 0 1;1 0 0 0; 0 0 0 1];
% indx(13,:) = [];


for i1 = 1:numel(condition)
    for j1 = 1:numel(condition{i1})
        it = 1;
        if ~isempty(condition{i1})
            ib = 1;
            inb = 1;
            for ii = 1:16
                if rem(ii,2) ~= 0
                    condR{i1}(j1).Bodies(ib,:) = condition{i1}{j1}(ii).answers;
                    ib = ib + 1;
                else
                    condR{i1}(j1).NonBodies(inb,:) = condition{i1}{j1}(ii).answers;
                    inb = inb + 1;
                end;
            end;
            it = it + 1;
        end;
    end;
end;

% parse data for psignfit
% snr = fliplr(100-unique(cell2mat(uNoiseLvls)));%[20 28 40 60];%% Set SNR levels used
% snrf = [-(snr(4)) -(snr(3)) -(snr(2)) -(snr(1)) snr(1) snr(2) snr(3) snr(4)]/100;
if t1 == 1
    snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
elseif t1 == 2
    snrf = [-0.8 -0.6 -0.4 -0.2 0.2 0.4 0.6 0.8];
elseif t1 == 3
    snrf = [-0.8 -0.6 -0.4 -0.2 0.2 0.4 0.6 0.8];
elseif t1 == 4
    snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
elseif t1 == 5
    snrf = [-0.4 -0.3 -0.2 -0.1 0.1 0.2 0.3 0.4];
elseif t1 == 6
    snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
elseif t1 == 7
    
end;

data = cell(0);
cond = cell2mat(condR);
for i1 = 1:numel(cond)
    data{i1} = zeros(numel(snrf),3);data{i1}(:,1) = snrf;
    data{i1}(1:4,2) = cond(i1).NonBodies(1:4,1);
    data{i1}(1:4,3) = cond(i1).NonBodies(1:4,2) + cond(i1).NonBodies(1:4,1);
    cBodies = flipud(cond(i1).Bodies(1:4,:));
    data{i1}(5:8,2) = cBodies(1:4,2);
    data{i1}(5:8,3) = cBodies(1:4,2) + cBodies(1:4,1);
end;
data = cell2mat(data');
clear cBodies
data2 = cell(0);
for i1 = 1:numel(cond)
    data2{i1} = zeros(numel(snrf),3);data2{i1}(:,1) = snrf;
    data2{i1}(1:4,2) = cond(i1).NonBodies(5:8,1);
    data2{i1}(1:4,3) = cond(i1).NonBodies(5:8,2) + cond(i1).NonBodies(5:8,1);
    cBodies = flipud(cond(i1).Bodies(5:8,:));
    data2{i1}(5:8,2) = cBodies(1:4,2);
    data2{i1}(5:8,3) = cBodies(1:4,2) + cBodies(1:4,1);
end;
data2 = cell2mat(data2');


% parse data for percent shift calculation
Ic = 0; ydNS = 0; ydS = 0;xdata = []; ydata = [];
uV = unique(data(:,1));
for i1 = 1:numel(uV)
    ind = find(uV(i1) == data(:,1));
    if numel(ind)>1
        dsum = sum(data(ind,2:end));
    else
        dsum = data(ind,2:end);
    end;
    ydNS(i1) = dsum(1)/(dsum(2));
    Ic(i1) = 0;
    xdata(i1,:) = [Ic(i1), uV(i1)];
    ydata(i1,:) = ydNS(i1);
end;
uV = unique(data2(:,1));
for i1 = 1:numel(uV)
    ind = find(uV(i1) == data2(:,1));
    if numel(ind)>1
        dsum = sum(data2(ind,2:end));
    else
        dsum = data2(ind,2:end);
    end;
    ydS(i1) = dsum(1)/(dsum(2));
    Ic(i1+8) = 1;
    xdata(i1+8,:) = [Ic(i1+8), uV(i1)];
    ydata(i1+8,:) = ydS(i1);
end;
% Transpose if necessary
if size(ydata,1)<size(ydata,2)
    ydata = ydata';
end
% Check range of data
if min(ydata)<0 || max(ydata)>1
    % Normalise data to range 0 to 1
    ydata = (ydata-min(ydata)) / (max(ydata)-min(ydata));
end

F = @(z) modelEquationP( z, xdata, ydata );
% F = @(x) 1/(1 + exp(-(x(1) + x(2)*xdata(:,2) + x(3)*xdata(:,1))))-ydata';
% yns = 1/(1 + exp(-(alpha + beta*xd + lambda*Ic)));
lb = [-10 -10 -10]; ub = [10 10 10];
z = [1 1 1];
options = optimoptions('lsqnonlin','MaxFunEvals',length(z)*1000,'Algorithm','trust-region-reflective');
problem = createOptimProblem('lsqnonlin','x0',[1 1 1],...
    'objective',F,'lb',lb,'ub',ub,...
    'options',options, 'xdata',xdata,'ydata',ydata);
%'lb',lb,'ub',ub,...
ms = MultiStart('UseParallel',false,'Display','iter','StartPointsToRun','bounds');
% start points
stpoints = RandomStartPointSet('NumStartPoints',100);%
[x,errormulti] = run(ms,problem,stpoints);
results.fit = x;
results.shift = x(3)/x(2);
results.data = [xdata, ydata];
if param.analysisFull == 1;
    % check significance of shift;
    for r1 = 1:1000
        % randomize the stim and non stim conditions
        clear datans datas
        for s1 = 1:numel(data(:,3))
            dnsb = data(s1,2);dnsnb = data(s1,3) - dnsb;
            dsb = data2(s1,2);dsnb = data2(s1,3) - dsb;
            nums = [zeros(dnsnb + dsnb, 1)' ones(dnsb+dsb,1)'];
            datans(s1,1:3) = data(s1,1:3);nn = randsample(nums, data(s1,3));
            datans(s1,2) = sum(nn);
            datas(s1,1:3) = data2(s1,1:3);nn2 = randsample(nums, data2(s1,3));
            datas(s1,2) = sum(nn2);
        end;
        % parse data for percent shift calculation
        Ic = 0; ydNS = 0; ydS = 0;
        uV = unique(datans(:,1));
        for i1 = 1:numel(uV)
            ind = find(uV(i1) == datans(:,1));
            if numel(ind)>1
                dsum = sum(datans(ind,2:end));
            else
                dsum = datans(ind,2:end);
            end;
            ydNS(i1) = dsum(1)/(dsum(2));
            Ic(i1) = 0;
            xdata(i1,:) = [Ic(i1), uV(i1)];
            ydata(i1,:) = ydNS(i1);
        end;
        uV = unique(datas(:,1));
        for i1 = 1:numel(uV)
            ind = find(uV(i1) == datas(:,1));
            if numel(ind)>1
                dsum = sum(datas(ind,2:end));
            else
                dsum = datas(ind,2:end);
            end;
            ydS(i1) = dsum(1)/(dsum(2));
            Ic(i1+8) = 1;
            xdata(i1+8,:) = [Ic(i1+8), uV(i1)];
            ydata(i1+8,:) = ydS(i1);
        end;
        F = @(z) modelEquationP( z, xdata, ydata );
        % F = @(x) 1/(1 + exp(-(x(1) + x(2)*xdata(:,2) + x(3)*xdata(:,1))))-ydata';
        % yns = 1/(1 + exp(-(alpha + beta*xd + lambda*Ic)));
        lb = [-10 -10 -10]; ub = [10 10 10];
        z = [1 1 1];
        options = optimoptions('lsqnonlin','MaxFunEvals',length(z)*1000,'Algorithm','trust-region-reflective');
        problem = createOptimProblem('lsqnonlin','x0',[1 1 1],...
            'objective',F,'lb',lb,'ub',ub,...
            'options',options, 'xdata',xdata,'ydata',ydata);
        %'lb',lb,'ub',ub,...
        ms = MultiStart('UseParallel',true,'StartPointsToRun','bounds');
        % start points
        stpoints = RandomStartPointSet('NumStartPoints',100);%
        [x,errormulti] = run(ms,problem,stpoints);
        nullDistShift(r1) = x(3)/x(2);
        r1
    end;
    results.nullDistShift = nullDistShift;clear nullDistShift
    results.shiftPval = sum(results.nullDistShift>results.shift)/numel(results.nullDistShift);
end
end