function [LFPresults, indx] = analyzeLFPGamma(param)
if ~isfield(param, 'CellIndex2')
    param.CellIndex2 = param.CellIndex;
end
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
gammaT = {};
% analyse LFP for body vs nonbody comparisons
iter =1;
for p1 = 1:numel(param.CellIndex2)
    load(fullfile(param.structPath,param.CellIndex2{p1},[param.CellIndex2{p1} 'LFPdata.mat']));
    TFAcat{iter} = cell2mat(LFP.carrTFAcat);
    
    for t1 = 1:numel(LFP.carrTFAacceptedTrlsStim)
        trialsPerStim(t1) = numel(LFP.carrTFAacceptedTrlsStim{t1});
        iStimOnset = LFP.iStimOnset;
        matAvEnergyStimRaw = LFP.matTFAraw(:,:,t1);
        arrBaseline = mean(matAvEnergyStimRaw(((iStimOnset - param.iBaseline - 1) : (iStimOnset - 1)), : ), 1); % [-100; 0] ms
        matBaseline = repmat(arrBaseline, [size(matAvEnergyStimRaw, 1), 1]);
        TFAraw = matAvEnergyStimRaw ./ matBaseline;
        hg(t1) = mean(mean(TFAraw(551:750,1:50)));
        mg(t1) = mean(mean(TFAraw(551:750,51:90)));
        lg(t1) = mean(mean(TFAraw(551:750,91:120)));
        beta(t1) = mean(mean(TFAraw(551:750,121:137)));
        alpha(t1) = mean(mean(TFAraw(551:750,138:142)));
        gamma2(t1) = mean(mean(TFAraw(551:750,1:90)));
    end
    maxPower(iter).hg = max(hg);clear hg;
    maxPower(iter).mg = max(mg);clear mg;
    maxPower(iter).lg = max(lg);clear lg;
    maxPower(iter).beta = max(beta);clear beta;
    maxPower(iter).alpha = max(alpha);clear alpha;
    maxPower(iter).gamma = max(gamma2);clear gamma;
    minTrials(iter) = min(trialsPerStim);
    carrCatNames = LFP.carrCategory;
    indxc = 1:length(carrCatNames);
    gammaT1 = [];
    for c1 = 1:numel(catNamesTarget)
        iCat = strcmp(carrCatNames, catNamesTarget(c1));
        ii2  = LFP.arrLFPNumTrCat== indxc(iCat);
        gammaT1(c1)= nanmean(abs(gamma2(ii2) - nanmean(gamma2(ii2))));
    end
    gammaT{iter} = gammaT1;
    iter = iter + 1;
    p1
end
TFAcat = TFAcat(minTrials>=1);
maxPower = maxPower(minTrials>=1);
indx = find(minTrials>=1);
gammaT = gammaT(indx);
% preprocess cells
TFAcatAll = cell2mat(TFAcat);
TFAcatAllcat = reshape(TFAcatAll,150,7200,numel(TFAcat));
% catNamesTarget = { 'monfac','humfac','monbod','humbod','monobj','humobj','fruits','birds','sculp', 'animals'};


for i1 = 1:numel(TFAcat)
    mTFAcat = TFAcatAllcat(:,:,i1);
    meanTFAcat = reshape(mTFAcat,150,1200,6);
    for tt = 1:6
        mmcTFAcat{tt} = meanTFAcat(:,:,tt);
    end
    LFP.carrTFAcat =  mmcTFAcat;
    % plots
    param.bFullTrial = 0;
    param.bCombinedPlot = 1;
    matMeanTFA = LFP.matTFA;
    carrTFAcat = LFP.carrTFAcat;
    iLowFrq = param.iLowFrq;
    iHighFrq = param.iHighFrq;
    iStimOnset = LFP.iStimOnset;
    iStimOffset = LFP.iStimOffset;
    iBaseline = param.iBaseline;
    carrCatNames = LFP.carrCategory;
    bFullTrial = param.bFullTrial;
    bCombinedPlot = param.bCombinedPlot;
    iNumTrials = LFP.iNumTrials;
    strSaveNameCombPlot = fullfile(param.structPath,'LFPresults','GABBANA_ALL_Cells_figLFPnorm.fig');
    iStart = iStimOnset - iBaseline;
    iEnd = iStimOffset + iStimOffset - iStimOnset;
    iMarkOnset = iBaseline;
    iMarkOffset = iMarkOnset + (iStimOffset - iStimOnset);
    % scaling the TFA
    for (iCat = 1 : length(carrCatNames))
        % gets the max/min power in the abbreviated trial (for scaling the plot) :: Update : IS:04.01.2011
        arrMaxTFA(iCat) = max(max(carrTFAcat{iCat}(:, iStart : iEnd)));
        arrMinTFA(iCat) = min(min(carrTFAcat{iCat}(:, iStart : iEnd)));
    end    % for all categories
    iMinScale = min(arrMinTFA) - 0.1;      %
    iMaxScale = max(arrMaxTFA) + 0.1;      %
    
    iMinScale = 0.5;
    iMaxScale = 3.0;
    maxAll = max(arrMaxTFA);
    indxc = 1:length(carrCatNames);
    for iC = 1 : length(carrCatNames)
        %         subplot(2, 5, iCat);
        iCat = strcmp(carrCatNames, catNamesTarget(iC));
        LFPresults(i1).highGamma{iC} = carrTFAcat{iCat}(1:50, iStart + 151 : iEnd - 150)./maxPower(i1).hg;
        LFPresults(i1).middleGamma{iC} = carrTFAcat{iCat}(51:90, iStart + 151 : iEnd - 150)./maxPower(i1).mg;
        LFPresults(i1).lowGamma{iC} = carrTFAcat{iCat}(91:120, iStart + 151 : iEnd - 150)./maxPower(i1).lg;
        LFPresults(i1).beta{iC} = carrTFAcat{iCat}(121:137, iStart + 151 : iEnd - 150)./maxPower(i1).beta;
        LFPresults(i1).alpha{iC} = carrTFAcat{iCat}(138:142, iStart + 151 : iEnd - 150)./maxPower(i1).alpha;
        LFPresults(i1).gamma{iC} = carrTFAcat{iCat}(1:90, iStart + 151 : iEnd - 150)./maxPower(i1).gamma;
        LFPresults(i1).gammaMean(iC) = mean(mean(carrTFAcat{iCat}(1:90, iStart + 151 : iEnd - 150)./maxPower(i1).gamma));
        LFPresults(i1).gammaMeanAbsoluteDeviation(iC) = gammaT{i1}(iC);
    end    % for each category
end


