function [ Bstruct, conditions, uNoiseLvls] = analysisBehavDataStim( param, i1 )


CellIndex = param.CellIndex{i1};
%% load saved data
fPath = fullfile(param.structPath, CellIndex);
files = dir(fullfile(fPath, '*.mat'));
files = struct2cell(files);
filePaths = files(1,1:end,1);
searchStrM = 'stim';%'training';%[param.testType];
analysisIndxM = ~cellfun(@isempty,regexp(filePaths, searchStrM));
Indx = filePaths(analysisIndxM);
for k = 1:numel(Indx)
    tmp = fullfile(fPath, Indx(k));
    strDataPathM = tmp{1};
    tmp1 = load('-mat', strDataPathM);
    structData2{k} = tmp1.structData;
end;
outP = structData2;
%% Iterate through each test run during a session
for s1 = 1:numel(outP)
    clear structData photo photoE pE output1 stimNames spikes
    structData = outP{s1};
    % examine answers
    for ssk = 1:numel(structData.trial)
        ans1(ssk) = structData.trial(ssk).dsp_data.Answer;
        if any([1 0] == ans1(ssk))
            ans2(ssk) = 11;
        else
            ans2(ssk) = 9;
        end;
    end;
    % analyze photoevents
    for pe = 1:numel(structData.trial)
        photo{pe} = structData.trial(pe).dsp_data.PhotoEvents;
        if ~isempty(photo{pe}) % is not empty
            if length(photo{pe})== 3
                f1 = photo{pe}(1);f2 = photo{pe}(2);f3 = photo{pe}(3);
                diffph21 = f2 - f1;diffph32 = f3 - f2;
                photoE(pe).time_S1 = diffph21;
                photoE(pe).time_ISI = diffph32;
                photoE(pe).f1 = f1; photoE(pe).f2 = f2; photoE(pe).f3 = f3;
                pE(pe) = 1;
            else
                pE(pe) = 6;
            end;
        else
            pE(pe) = 6;
        end;
    end;
    
    % eyemovement analysis
    % eyeM = eyemovements(structData, photo, pE);
    
    % stimulation params analysis
    
    % checks
    for all1 = 1:numel(structData.trial)
        if ((((ans2(all1))==11))) %&& (pE(all1)) == 1) == 1 )%& (stp(all1)) == 1 & (eyeM(all1)) == 1 & (pE(all1)) == 1) == 1
            output1(all1) = 1;
        else
            output1(all1) = 2;
        end
    end
    
    
    indx1 = find(output1==1);
    if isempty(indx1) == 1
        photo = [];
        ans1 = [];
    else
        photo  = photoE(output1==1);
        ans1 = ans1(output1==1);
    end
    
    
    % possible conditions in stimuli names
    for id1 = 1:numel(structData.trial) % identities
        %         tmp =   structData.trial(id1).stimul_data.categor.current_stimul_names;
        %         tmps = strsplit(tmp,',');
        tmp = structData.trial(id1).stimul_data.transparent.bmp_name_transparent;
        if numel(strfind(tmp,'__')) == 2
            tmps = strsplit(tmp,'__');
            %         stimNames{id1} =   tmps{1}(2:end);
            stimNames{id1} = [tmps{2} '__' tmps{3} ];
            tmps2 = strsplit(tmps{1},'_');
            noiseLvls(id1) = str2num(tmps2{end});
        else
            tmps = strsplit(tmp,'__');
            stimNames{id1} = tmps{2};
            tmps2 = strsplit(tmps{1},'_');
            noiseLvls(id1) = str2num(tmps2{end});
        end;
    end;
    stimConditions = unique(stimNames);
    numStimConditions = numel(stimConditions);
    cIds = 1:numStimConditions;
    uNoiseLvls = unique(noiseLvls);
    for t1 = 1:numStimConditions
        Bstruct{s1}.Cond{t1}                  = [];
        Bstruct{s1}.Cond{t1}.conditionName   = [];
        Bstruct{s1}.Cond{t1}.time_reaction_incorrect     = [];
        Bstruct{s1}.Cond{t1}.time_reaction_correct    = [];
        Bstruct{s1}.Cond{t1}.answers_incorrect       = [];
        Bstruct{s1}.Cond{t1}.answers_correct       = [];
    end;
    
    for j1 = 1:numel(indx1)
        %         spikes{j1}.spikeEvents = structData.trial(indx1(j1)).dsp_data.SpikeEvents;
        %     for spike window
        %     spikes{j1}.spikeEvents  = structData(j1).SpikeEvents;
        behav{j1}.startTime    = floor(photo(j1).f1); % params.startSpikeWin is defined in terms of f1 event
        behav{j1}.endTime      = floor(photo(j1).f2); % params.endSpikeWin is defined in terms of f2 event
        behav{j1}.ISI          = floor(photo(j1).f3) - floor(photo(j1).f2);
        behav{j1}.Duration     = (behav{j1}.endTime - behav{j1}.startTime);
        %         rxnTime(j1) = structData.trial(indx1(j1)).stimul_data.time.reaction;
        %         if rxnTime(j1) ~= -1
        %             behav{j1}.time_reaction = rxnTime(j1) - (behav{j1}.Duration + behav{j1}.ISI);
        %         else
        %             behav{j1}.time_reaction = rxnTime(j1);
        %         end;
        %         %     for baseline window
        %         behav{j1}.BaselinespikeEvents  = behav{j1}.spikeEvents;
        %         behav{j1}.BaselinestartTime    = (photo(j1).f1 + param.startBaselineWin); % params.startBaselineWin is defined in terms of f1 event
        %         behav{j1}.BaselineendTime      = floor(photo(j1).f1 + param.endBaselineWin); % params.endBaselineWin is defined in terms of f1 event
        %         behav{j1}.BaselineDuration     = floor(behav{j1}.BaselineendTime - behav{j1}.BaselinestartTime);
        %         %       for PSTH
        %         behav{j1}.PSTHspikeEvents  = floor(structData.trial(indx1(j1)).dsp_data.SpikeEvents - photo(j1).f1);
        %         behav{j1}.PSTHstartTime    = -100; % params.startBaselineWin is defined in terms of f1 event
        %         behav{j1}.PSTHendTime      =  500; % params.endBaselineWin is defined in terms of f1 event
        %         behav{j1}.PSTHDuration     = (behav{j1}.PSTHendTime - behav{j1}.PSTHstartTime);
        %     condition classification
        tmp = structData.trial(id1).stimul_data.transparent.bmp_name_transparent;
        if numel(strfind(tmp,'__')) == 2
            tmps = strsplit(tmp,'__');
            %         stimNames{id1} =   tmps{1}(2:end);
            strCond = [tmps{2} '__' tmps{3} ];
        else
            tmps = strsplit(tmp,'__');
            strCond = tmps{2};
        end;
        behav{j1}.condition = cIds(strcmp(strCond,stimConditions));
        %     if ~isfield(structData.trial(indx1(j1)).stimul_data, 'current_stimul')
        %         spikes{j1}.condition = cIds(strcmp(structData.trial(indx1(j1)).stimul_data.current_stimul_name,stimConditions));
        %     else
        %         spikes{j1}.condition = cIds(strcmp(structData.trial(indx1(j1)).stimul_data.current_stimul.name,stimConditions));
        %     end
        behav{j1}.conditionCheck   = 1;
        %     count spikes
        %         behav{j1} = countSpikes(j1, behav);
        %     spike count per condition
        CIndx           = behav{j1}.condition;
        CN              = stimConditions(CIndx);
        %     if CIndx <= 100;
        if ans1(j1) == 0
            %             Bstruct{s1}.Cond{CIndx}.time_reaction_incorrect= [Bstruct{s1}.Cond{CIndx}.time_reaction_incorrect; behav{j1}.time_reaction];
            Bstruct{s1}.Cond{CIndx}.answers_incorrect  = [Bstruct{s1}.Cond{CIndx}.answers_incorrect; 1];
        else
            %             Bstruct{s1}.Cond{CIndx}.time_reaction_correct= [Bstruct{s1}.Cond{CIndx}.time_reaction_correct; behav{j1}.time_reaction];
            Bstruct{s1}.Cond{CIndx}.answers_correct  = [Bstruct{s1}.Cond{CIndx}.answers_correct; 1];
        end;
        
        Bstruct{s1}.Cond{CIndx}.conditionName  = [Bstruct{s1}.Cond{CIndx}.conditionName; CN];
        
        %     end;
        %         if isempty(behav{j1}.PSTHspikeEvents)
        %             behav{j1}.PSTHspikeEvents = NaN;
        %         end;
        %         Bstruct.Cond{CIndx}.PSTHspikes  = [Bstruct.Cond{CIndx}.PSTHspikes; {behav{j1}.PSTHspikeEvents}];
        
    end;
    
    %       Spikerate averaging out for all the trials
    %     for m1 = 1:size(Bstruct.Cond,2),
    %         Bstruct.AverageNetRateCond{m1} = sum(Bstruct.Cond{m1}.spikeRateNet)/length(Bstruct.Cond{m1}.spikeRateNet); % Per condition average net spike rate
    %         Bstruct.AverageTotalRateCond{m1} = sum(Bstruct.Cond{m1}.spikeRateTotal)/length(Bstruct.Cond{m1}.spikeRateTotal); % Per condition average total spike rate
    %     end;
    %
    %     %       Standard error of mean of total presentation of stimuli
    %     for m1 = 1:size(Bstruct.Cond,2),
    %         Bstruct.StandardErrorNetCond{m1} = std(Bstruct.Cond{m1}.spikeRateNet)/(length(Bstruct.Cond{m1}.spikeRateNet)^0.5); % Per condition average net spike rate
    %         Bstruct.StandardErrorTotalCond{m1} = std(Bstruct.Cond{m1}.spikeRateTotal)/(length(Bstruct.Cond{m1}.spikeRateTotal)^0.5); % Per condition average total spike rate
    %     end;
    Bstruct{s1}.CellName = CellIndex;
    Bstruct{s1}.stimConditions = stimConditions;
end;
i1
if isfield(outP{1},'conditions')
    for i1 = 1:numel(outP)
        conditions{i1} = outP{i1}.conditions;
    end;
else
    conditions = {};
end;
end
