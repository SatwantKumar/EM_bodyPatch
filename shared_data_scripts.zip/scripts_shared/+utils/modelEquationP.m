function [ rS ] = modelEquationP( z, xdata, ydata )
Ic = xdata(:,1);
xd = xdata(:,2:end);
alpha = z(1);
beta = z(2);
lambda = z(3);
% F = @(g,l,u,v,x) g+(1-g-l)*0.5*(1+erf((x-u)/sqrt(2*v^2)));
% 1./(1+exp(-(x-alpha)./beta))
yns = (1./(1 + exp(-(alpha + beta*xd(1:8) + lambda*Ic(1:8)))));
ys = (1./(1 + exp(-(alpha + beta*xd(9:16) + lambda*Ic(9:16)))));
% yns = 1./(1+exp(-(xd(1:8)-z(1))./beta))';
% ys = 1./(1+exp(-(xd(9:16)-z(3))./beta))';
rS = ([yns',ys'] - ydata');
end

