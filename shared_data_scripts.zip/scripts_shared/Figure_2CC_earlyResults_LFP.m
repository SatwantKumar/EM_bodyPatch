%% Figure for 2AFC results
% parameters for file parsing (dataPreprocessing)
clear; close all;
%Add path
param.dropboxPath = '';% Specify path to working dir
param.carrCategory = {'monbod', 'monobj', 'animals', ...
    'humbod', 'humfac', 'humobj'};
param.carrStimNumPerCat = {[2 5 7 9 10 12 13 15 16 19], ...
    [1 3 4 5 6 8 10 11 13 17], ...
    [2 4 6 8 10 11 12 13 17 18], ...
    [2 3 4 5 10 12 17 18 19 20], ...
    [2 3 4 7 8 10 12 13 15 19], ...
    [3 4 5 10 13 15 16 17 18 20]};     % stim numbers for Category_EVEN
%   parameters for eye movements
param.startEyeM = -100; % param.start is defined in terms of f1 event
param.endEyeM = 200; % param.end is defined in terms of f2 event
% Parameters for spike analysis
param.spikeRateType = 0; % 1 = for Net Response, 0 = Total respone i.e. without using baseline.
param.Trials = 5; % number of trials to consider for avg. spike count per stimuli.
param.minTrials = 4; % minimum number of trials to consider in case of aborted generations.
param.startSpikeWin = +50; % param.startSpikeWin is defined in terms of f1 event
param.endSpikeWin = +50; % param.endSpikeWin is defined in terms of f2 event
param.startBaselineWin = -100; % param.startBaselineWin is defined in terms of f1 event,0 mean = f1
param.endBaselineWin = 0; % param.endBaselineWin is defined in terms of f1 event
% for PSTH
param.startPSTH = -100;
param.endPSTH = 400;
param.binsize = 10;
% LFP parameters
param.strChannel = 4;
param.bPerTrial = 1;
param.bPlot = 1;
param.iLFPmin = 2;    % -- range for the LFP amplitude
param.iLFPmax = 4093; % /
param.iLowFrq = 60;
param.iHighFrq  = 150;
param.iBaseline = 100; % [ms] before the start
param.structPath = ''; % path to save CSTRUCT file
param.LFPresutsDir = ''; % location of the LFP save dir
param.savepath = ''; % location of the save dir
% set the tickdirs to go out - need this specific order
set(groot, 'DefaultAxesTickDir', 'out');
set(groot, 'DefaultAxesTickDirMode', 'manual');

% general graphics.
set(groot, ...
    'DefaultFigureColorMap', linspecer, ...
    'DefaultFigureColor', 'w', ...
    'DefaultAxesLineWidth', 0.5, ...
    'DefaultAxesXColor', 'k', ...
    'DefaultAxesYColor', 'k', ...
    'DefaultAxesFontUnits', 'points', ...
    'DefaultAxesFontSize', 8, ...
    'DefaultAxesFontName', 'Helvetica', ...
    'DefaultLineLineWidth', 1, ...
    'DefaultTextFontUnits', 'Points', ...
    'DefaultTextFontSize', 8, ...
    'DefaultTextFontName', 'Helvetica', ...
    'DefaultAxesBox', 'off', ...
    'DefaultAxesTickLength', [0.02 0.025]);

% type cbrewer without input args to see all possible sets of colormaps
colors = cbrewer('qual', 'Set1', 10);

hIndx = figure;

%% Body vs Objects
param.analysisFull = 0;
%%% Stimulation Brain - Animals vs Objects
%% Figure 1a Sample session from Monkey B
clear('data', 'data2','xdata','ydata','x','snrf','results')
t1 = 1;
param.CellIndex = {'BS19'};
[data, data2, xdata, ydata, x, snrf, results] = runFit2AFC(param, t1, 1);
snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
markerstyles = {'o', '^'};
subplot(6,3,1)
options             = struct;   % initialize as an empty struct
options.nblocks        = 1; % number of blocks required to start pooling
options.sigmoidName = 'logistic';   % choose a cumulative Gaussian as the sigmoid
options.expType     = 'YesNo';%'equalAsymptote';%
options.fixedPars = NaN(5,1);
resultNS = psignifit(data,options);
resultS = psignifit(data2,options);
plotOptions.lineColor = colors(5, : );
plotOptions.dataColor = colors(5,:);
plotOptions.CIthresh       = false;
plotOptions.dataSize    = 5;
plotOptions.plotThresh   = false;
plotOptions.plotAsymptote  = false;
[hline,hdata] = plotPsych(resultS,plotOptions);
hold on
plotOptions.lineColor = colors(4, : );
plotOptions.dataColor = colors(4,:);
[hline2,hdata2] = plotPsych(resultNS,plotOptions);
%     legend([hline,hline2],'Fit Stim','Fit Non Stim')
nNonStim = sum(data(:,3));
nStim = sum(data2(:,3));
hold off;
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)
%% Pooled data for Animals vs Objs for Monkey B
clear('data', 'data2','xdata','ydata','x','snrf','results')
load('pooledDataMonkeyB_animVsObj_early.mat')
snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
dataPool = []; data2Pool = [];
snru = unique(data(:,1));
for s1 = 1:numel(snru)
    in = find(snru(s1)==data(:,1));
    dataPool(s1,:) = [snru(s1),sum(data(in,2)),sum(data(in,3))];
    in2 = find(snru(s1)==data2(:,1));
    data2Pool(s1,:) = [snru(s1),sum(data2(in2,2)),sum(data2(in2,3))];
    succs1 = sum(data(in,2)); total1 = sum(data(in,3));fails1 = total1-succs1;
    vals1=[ones(1,succs1) zeros(1,fails1)];
    bootstat1 = bootstrp(10000,@sum,vals1);
    ci1(s1,:) = quantile(bootstat1,[.05 .95])/(total1);
    succs2 = sum(data2(in,2)); total2 = sum(data2(in,3));fails2 = total2-succs2;
    vals2=[ones(1,succs2) zeros(1,fails2)];
    bootstat2 = bootstrp(10000,@sum,vals2);
    ci2(s1,:) = quantile(bootstat2,[.05 .95])/(total2);
end
markerstyles = {'.', '.'}; % triangular and round markers
subplot(6,3,4)
hold on;
h = ploterr(xdata(1:8,2), ydata(1:8), ...
    [], {ci1(:,1) ci1(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(2, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{1}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(2, : )); % make the marker open
handles(1) = h(1);
h = ploterr(xdata(9:16,2), ydata(9:16), ...
    [], {ci2(:,1) ci2(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(1, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{2}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(1, : )); % make the marker open
handles(2) = h(1);
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)

% LFP gamma (60 -150 HZ)

param.startRow = 2; % Excel sheet start row.
param.endRow = 28; %Excel sheet end row.
param.CellIndex = {'BM04';'BM05';'BM06';'BM07';'BM08';'BM09';'BM10';'BM11';...
    'BM12';'BM13';'BM14';'BM15';'BM16';'BM18';'BM19';'BM25'};
[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(6,3,7)

% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2);
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);

hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)

errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)

gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj),sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');
title(['A0M0:Brain MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)










%% Figure: Sample session from Monkey B for Faces vs Obj
t1 = 2;
clear('data', 'data2','xdata','ydata','x','snrf','results')

param.CellIndex = {'BSF07'};%{'BSF01'; 'BSF02';'BSF03';'BSF04';'BSF05';'BSF06';'BSF07';'BSF08';'BSF09'};
[data, data2, xdata, ydata, x, snrf, results] = runFit2AFC(param, t1, 1);
snrf = [-0.8 -0.6 -0.4 -0.2 0.2 0.4 0.6 0.8];
markerstyles = {'.', '.'};
subplot(6,3,10)
options             = struct;   % initialize as an empty struct
options.nblocks        = 1; % number of blocks required to start pooling
options.sigmoidName = 'logistic';   % choose a cumulative Gaussian as the sigmoid
options.expType     = 'YesNo';%'equalAsymptote';%
options.fixedPars = NaN(5,1);
resultNS = psignifit(data,options);
resultS = psignifit(data2,options);
plotOptions.lineColor = colors(5, : );
plotOptions.dataColor = colors(5,:);
plotOptions.CIthresh       = false;
plotOptions.dataSize    = 5;
plotOptions.plotThresh   = false;
plotOptions.plotAsymptote  = false;
[hline,hdata] = plotPsych(resultS,plotOptions);
hold on
plotOptions.lineColor = colors(4, : );
plotOptions.dataColor = colors(4,:);
[hline2,hdata2] = plotPsych(resultNS,plotOptions);
nNonStim = sum(data(:,3));
nStim = sum(data2(:,3));
hold off;

xlabel('Stimulus level')
ylabel('Face response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Pooled data for Faces vs Objs for Monkey B
t1 = 2;
clear('data', 'data2','xdata','ydata','x','snrf','results')
load('pooledDataMonkeyB_FacesVsObj_early.mat')
snrf = [-0.8 -0.6 -0.4 -0.2 0.2 0.4 0.6 0.8];
dataPool = []; data2Pool = [];
snru = unique(data(:,1));
for s1 = 1:numel(snru)
    in = find(snru(s1)==data(:,1));
    dataPool(s1,:) = [snru(s1),sum(data(in,2)),sum(data(in,3))];
    in2 = find(snru(s1)==data2(:,1));
    data2Pool(s1,:) = [snru(s1),sum(data2(in2,2)),sum(data2(in2,3))];
    succs1 = sum(data(in,2)); total1 = sum(data(in,3));fails1 = total1-succs1;
    vals1=[ones(1,succs1) zeros(1,fails1)];
    bootstat1 = bootstrp(10000,@sum,vals1);
    ci1(s1,:) = quantile(bootstat1,[.05 .95])/(total1);
    succs2 = sum(data2(in,2)); total2 = sum(data2(in,3));fails2 = total2-succs2;
    vals2=[ones(1,succs2) zeros(1,fails2)];
    bootstat2 = bootstrp(10000,@sum,vals2);
    ci2(s1,:) = quantile(bootstat2,[.05 .95])/(total2);
end
markerstyles = {'.', '.'}; % triangular and round markers
subplot(6,3,13)
hold on;
h = ploterr(xdata(1:8,2), ydata(1:8), ...
    [], {ci1(:,1) ci1(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(5, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{1}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(5, : )); % make the marker open
handles(1) = h(1);
h = ploterr(xdata(9:16,2), ydata(9:16), ...
    [], {ci2(:,1) ci2(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(4, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{2}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(4, : )); % make the marker open
handles(2) = h(1);
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)
param.startRow = 2; % Excel sheet start row.
param.endRow = 28; %Excel sheet end row.
param.CellIndex = {'BM20';'BM21';'BM22';'BM23';'BM24';'BM26';'BM27';'BM28';...
    'BM29'};
[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(6,3,16)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2); 
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);
hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)

errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');
title(['Brain MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)




%% Figure: Sample session from Monkey B for Houses vs Obj
t1 = 3;
clear('data', 'data2','xdata','ydata','x','snrf','results')

param.CellIndex = {'BSH03'};%{'BSH01';'BSH02';'BSH03'};
[data, data2, xdata, ydata, x, snrf, results] = runFit2AFC(param, t1, 1);
snrf = [-0.8 -0.6 -0.4 -0.2 0.2 0.4 0.6 0.8];
markerstyles = {'o', '^'};
subplot(6,3,12)
options             = struct;   % initialize as an empty struct
options.nblocks        = 1; % number of blocks required to start pooling
options.sigmoidName = 'logistic';   % choose a cumulative Gaussian as the sigmoid
options.expType     = 'YesNo';%'equalAsymptote';%
options.fixedPars = NaN(5,1);
% options.fixedPars(3) = 0;
% options.fixedPars(4) = 0;
% options.fixedPars(5) = 0;% fixed the last parameter
resultNS = psignifit(data,options);
resultS = psignifit(data2,options);
plotOptions.lineColor = colors(5, : );
plotOptions.dataColor = colors(5,:);
plotOptions.CIthresh       = false;
plotOptions.dataSize    = 5;
plotOptions.plotThresh   = false;
plotOptions.plotAsymptote  = false;
[hline,hdata] = plotPsych(resultS,plotOptions);
hold on
plotOptions.lineColor = colors(4, : );
plotOptions.dataColor = colors(4,:);
[hline2,hdata2] = plotPsych(resultNS,plotOptions);
%     legend([hline,hline2],'Fit Stim','Fit Non Stim')
nNonStim = sum(data(:,3));
nStim = sum(data2(:,3));
%     title(['N(non stim) = ' num2str(nNonStim) ', N(stim) = ' num2str(nStim)]);
hold off;
xlabel('Stimulus level')
ylabel('House response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Pooled data for Houses vs Objs for Monkey B
t1 = 3;
clear('data', 'data2','xdata','ydata','x','snrf','results')
load('pooledDataMonkeyB_HousesVsObj_early.mat')
snrf = [-0.8 -0.6 -0.4 -0.2 0.2 0.4 0.6 0.8];
dataPool = []; data2Pool = [];
snru = unique(data(:,1));
for s1 = 1:numel(snru)
    in = find(snru(s1)==data(:,1));
    dataPool(s1,:) = [snru(s1),sum(data(in,2)),sum(data(in,3))];
    in2 = find(snru(s1)==data2(:,1));
    data2Pool(s1,:) = [snru(s1),sum(data2(in2,2)),sum(data2(in2,3))];
    succs1 = sum(data(in,2)); total1 = sum(data(in,3));fails1 = total1-succs1;
    vals1=[ones(1,succs1) zeros(1,fails1)];
    bootstat1 = bootstrp(10000,@sum,vals1);
    ci1(s1,:) = quantile(bootstat1,[.05 .95])/(total1);
    succs2 = sum(data2(in,2)); total2 = sum(data2(in,3));fails2 = total2-succs2;
    vals2=[ones(1,succs2) zeros(1,fails2)];
    bootstat2 = bootstrp(10000,@sum,vals2);
    ci2(s1,:) = quantile(bootstat2,[.05 .95])/(total2);
end
markerstyles = {'.', '.'}; % triangular and round markers
subplot(6,3,15)
hold on;
h = ploterr(xdata(1:8,2), ydata(1:8), ...
    [], {ci1(:,1) ci1(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(5, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{1}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(5, : )); % make the marker open
handles(1) = h(1);
h = ploterr(xdata(9:16,2), ydata(9:16), ...
    [], {ci2(:,1) ci2(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(4, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{2}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(4, : )); % make the marker open
handles(2) = h(1);
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)


param.startRow = 2; % Excel sheet start row.
param.endRow = 28; %Excel sheet end row.
param.CellIndex = {'BM26';'BM25';'BM29'};
[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(6,3,18)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2); 
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));

gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);
hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');
title(['Brain MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)



%% Gabbana 2CC Body vs Objects (early) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Sample example from Monkey G
t1 = 4;
clear('data', 'data2','xdata','ydata','x','snrf','results')
param.CellIndex = {'GSA09'};%
[data, data2, xdata, ydata, x, snrf, results] = runFit2AFC(param, t1, 1);
snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
markerstyles = {'o', '^'};
subplot(6,3,2)
options             = struct;   % initialize as an empty struct
options.nblocks        = 1; % number of blocks required to start pooling
options.sigmoidName = 'logistic';   % choose a cumulative Gaussian as the sigmoid
options.expType     = 'YesNo';%'equalAsymptote';%
options.fixedPars = NaN(5,1);
resultNS = psignifit(data,options);
resultS = psignifit(data2,options);
plotOptions.lineColor = colors(5, : );
plotOptions.dataColor = colors(5,:);
plotOptions.CIthresh       = false;
plotOptions.dataSize    = 5;
plotOptions.plotThresh   = false;
plotOptions.plotAsymptote  = false;
[hline,hdata] = plotPsych(resultS,plotOptions);
hold on
plotOptions.lineColor = colors(4, : );
plotOptions.dataColor = colors(4,:);
[hline2,hdata2] = plotPsych(resultNS,plotOptions);
%     legend([hline,hline2],'Fit Stim','Fit Non Stim')
nNonStim = sum(data(:,3));
nStim = sum(data2(:,3));
%     title(['N(non stim) = ' num2str(nNonStim) ', N(stim) = ' num2str(nStim)]);
hold off;
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Pooled data for Animals vs Objs for Monkey G
t1 = 4;
clear('data', 'data2','xdata','ydata','x','snrf','results')
load('pooledDataMonkeyG_animVsObj_early.mat')
snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
dataPool = []; data2Pool = [];
snru = unique(data(:,1));
for s1 = 1:numel(snru)
    in = find(snru(s1)==data(:,1));
    dataPool(s1,:) = [snru(s1),sum(data(in,2)),sum(data(in,3))];
    in2 = find(snru(s1)==data2(:,1));
    data2Pool(s1,:) = [snru(s1),sum(data2(in2,2)),sum(data2(in2,3))];
    succs1 = sum(data(in,2)); total1 = sum(data(in,3));fails1 = total1-succs1;
    vals1=[ones(1,succs1) zeros(1,fails1)];
    bootstat1 = bootstrp(10000,@sum,vals1);
    ci1(s1,:) = quantile(bootstat1,[.05 .95])/(total1);
    succs2 = sum(data2(in,2)); total2 = sum(data2(in,3));fails2 = total2-succs2;
    vals2=[ones(1,succs2) zeros(1,fails2)];
    bootstat2 = bootstrp(10000,@sum,vals2);
    ci2(s1,:) = quantile(bootstat2,[.05 .95])/(total2);
end
markerstyles = {'.', '.'}; % triangular and round markers
subplot(6,3,5)
hold on;
h = ploterr(xdata(1:8,2), ydata(1:8), ...
    [], {ci1(:,1) ci1(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(5, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{1}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(5, : )); % make the marker open
handles(1) = h(1);
h = ploterr(xdata(9:16,2), ydata(9:16), ...
    [], {ci2(:,1) ci2(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(4, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{2}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(4, : )); % make the marker open
handles(2) = h(1);
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)

param.startRow = 2; % Excel sheet start row.
param.endRow = 28; %Excel sheet end row.
param.CellIndex = {'GMA59';'GMA60';'GMA61';'GMA62';'GMA63';'GMA64';'GMA65';'GMA66';'GMA67';'GMA68';'GMA69';'GMA70';'GMA71';...
'GMA72';'GMA73';'GMA74';'GMA75'};
[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(6,3,8)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2);gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));

gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);
hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');
title(['Gab MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Figure- Sample session from Monkey G for Faces vs Obj
t1 = 5;
clear('data', 'data2','xdata','ydata','x','snrf','results')
param.CellIndex = {'GSF02'};%
[data, data2, xdata, ydata, x, snrf, results] = runFit2AFC(param, t1, 1);
snrf = [-0.4 -0.3 -0.2 -0.1 0.1 0.2 0.3 0.4];
markerstyles = {'.', '.'};
subplot(6,3,11)
options             = struct;   % initialize as an empty struct
options.nblocks        = 1; % number of blocks required to start pooling
options.sigmoidName = 'logistic';   % choose a cumulative Gaussian as the sigmoid
options.expType     = 'YesNo';%'equalAsymptote';%
options.fixedPars = NaN(5,1);
resultNS = psignifit(data,options);
resultS = psignifit(data2,options);
plotOptions.lineColor = colors(5, : );
plotOptions.dataColor = colors(5,:);
plotOptions.CIthresh       = false;
plotOptions.dataSize    = 5;
plotOptions.plotThresh   = false;
plotOptions.plotAsymptote  = false;
[hline,hdata] = plotPsych(resultS,plotOptions);
hold on
plotOptions.lineColor = colors(4, : );
plotOptions.dataColor = colors(4,:);
[hline2,hdata2] = plotPsych(resultNS,plotOptions);
%     legend([hline,hline2],'Fit Stim','Fit Non Stim')
nNonStim = sum(data(:,3));
nStim = sum(data2(:,3));
hold off;
xlabel('Stimulus level')
ylabel('Face response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Pooled data for Faces vs Objs for Monkey G
t1 = 5;
clear('data', 'data2','xdata','ydata','x','snrf','results')
load('pooledDataMonkeyG_FacesVsObj_early.mat')
snrf = [-0.4 -0.3 -0.2 -0.1 0.1 0.2 0.3 0.4];
dataPool = []; data2Pool = [];
snru = unique(data(:,1));
for s1 = 1:numel(snru)
    in = find(snru(s1)==data(:,1));
    dataPool(s1,:) = [snru(s1),sum(data(in,2)),sum(data(in,3))];
    in2 = find(snru(s1)==data2(:,1));
    data2Pool(s1,:) = [snru(s1),sum(data2(in2,2)),sum(data2(in2,3))];
    succs1 = sum(data(in,2)); total1 = sum(data(in,3));fails1 = total1-succs1;
    vals1=[ones(1,succs1) zeros(1,fails1)];
    bootstat1 = bootstrp(10000,@sum,vals1);
    ci1(s1,:) = quantile(bootstat1,[.05 .95])/(total1);
    succs2 = sum(data2(in,2)); total2 = sum(data2(in,3));fails2 = total2-succs2;
    vals2=[ones(1,succs2) zeros(1,fails2)];
    bootstat2 = bootstrp(10000,@sum,vals2);
    ci2(s1,:) = quantile(bootstat2,[.05 .95])/(total2);
end
markerstyles = {'.', '.'}; % triangular and round markers
subplot(6,3,14)
hold on;
h = ploterr(xdata(1:8,2), ydata(1:8), ...
    [], {ci1(:,1) ci1(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(5, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{1}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(5, : )); % make the marker open
handles(1) = h(1);
h = ploterr(xdata(9:16,2), ydata(9:16), ...
    [], {ci2(:,1) ci2(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(4, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{2}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(4, : )); % make the marker open
handles(2) = h(1);
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)


% LFP gamma (60 -150 HZ)

param.startRow = 2; % Excel sheet start row.
param.endRow = 28; %Excel sheet end row.
param.CellIndex = {'GMA76';'GMA72';'GMA73';'GMA74';'GMA75';'GMA77';'GMA78'};
[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(6,3,17)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2); gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);
hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');
title(['Gab MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Figure- Sample session from Monkey G for Animals vs Obj outside the body patch
t1 = 6;
clear('data', 'data2','xdata','ydata','x','snrf','results')

param.CellIndex = {'GSA03'};%;
[data, data2, xdata, ydata, x, snrf, results] = runFit2AFC(param, t1, 1);
snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
markerstyles = {'o', '^'};
 
subplot(6,3,3)
options             = struct;   % initialize as an empty struct
options.nblocks        = 1; % number of blocks required to start pooling
options.sigmoidName = 'logistic';   % choose a cumulative Gaussian as the sigmoid
options.expType     = 'YesNo';%'equalAsymptote';%
options.fixedPars = NaN(5,1);
resultNS = psignifit(data,options);
resultS = psignifit(data2,options);
plotOptions.lineColor = colors(5, : );
plotOptions.dataColor = colors(5,:);
plotOptions.CIthresh       = false;
plotOptions.dataSize    = 5;
plotOptions.plotThresh   = false;
plotOptions.plotAsymptote  = false;
[hline,hdata] = plotPsych(resultS,plotOptions);
hold on
plotOptions.lineColor = colors(4, : );
plotOptions.dataColor = colors(4,:);
[hline2,hdata2] = plotPsych(resultNS,plotOptions);
%     legend([hline,hline2],'Fit Stim','Fit Non Stim')
nNonStim = sum(data(:,3));
nStim = sum(data2(:,3));
%     title(['N(non stim) = ' num2str(nNonStim) ', N(stim) = ' num2str(nStim)]);
hold off;
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Pooled data for Animals vs Objs for Monkey G OutSide the Body patch
t1 = 6;
clear('data', 'data2','xdata','ydata','x','snrf','results')
load('pooledDataMonkeyG_animVsObj_early_outsideBodyPatch.mat')
snrf = [-0.6 -0.4 -0.28 -0.2 0.2 0.28 0.4 0.6];
dataPool = []; data2Pool = [];
snru = unique(data(:,1));
for s1 = 1:numel(snru)
    in = find(snru(s1)==data(:,1));
    dataPool(s1,:) = [snru(s1),sum(data(in,2)),sum(data(in,3))];
    in2 = find(snru(s1)==data2(:,1));
    data2Pool(s1,:) = [snru(s1),sum(data2(in2,2)),sum(data2(in2,3))];
    succs1 = sum(data(in,2)); total1 = sum(data(in,3));fails1 = total1-succs1;
    vals1=[ones(1,succs1) zeros(1,fails1)];
    bootstat1 = bootstrp(10000,@sum,vals1);
    ci1(s1,:) = quantile(bootstat1,[.05 .95])/(total1);
    succs2 = sum(data2(in,2)); total2 = sum(data2(in,3));fails2 = total2-succs2;
    vals2=[ones(1,succs2) zeros(1,fails2)];
    bootstat2 = bootstrp(10000,@sum,vals2);
    ci2(s1,:) = quantile(bootstat2,[.05 .95])/(total2);
end
markerstyles = {'.', '.'}; % triangular and round markers
subplot(6,3,6)
hold on;
h = ploterr(xdata(1:8,2), ydata(1:8), ...
    [], {ci1(:,1) ci1(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(5, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{1}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(5, : )); % make the marker open
handles(1) = h(1);
h = ploterr(xdata(9:16,2), ydata(9:16), ...
    [], {ci2(:,1) ci2(:,2)}, ...
    '-', 'abshhxy', 0);
set([h(: )],  'color', colors(4, : )); % set a nice color for the lines
set(h(1), 'markersize', 15, 'marker', markerstyles{2}, 'markerfacecolor', 'w',...
    'markeredgecolor',colors(4, : )); % make the marker open
handles(2) = h(1);
xlabel('Stimulus level')
ylabel('Body response')
ax = gca;ax.YLim = [0 1];
axis tight; ax = gca;ax.YLim = [0 1];
ax.XTick = [-0.5 0 0.5];ax.YTick = [0 0.2 0.4 0.6 0.8 1];
ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
title(['Trials = ' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ', SessionNum = ' num2str(numel(param.CellIndex))],'FontSize',8)


% LFP gamma (60 -150 HZ)

param.startRow = 2; % Excel sheet start row.
param.endRow = 28; %Excel sheet end row.
param.CellIndex = {'GMA55';'GMA56';'GMA57';'GMA58'};
[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(6,3,9)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2); gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);
hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');

title(['Gab MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)

