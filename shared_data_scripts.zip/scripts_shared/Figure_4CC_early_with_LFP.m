%% Figure for 4AFC results
% parameters for file parsing (dataPreprocessing)
clear; close all;
%Add path
param.dropboxPath = '';% Specify path to working dir
param.carrCategory = {'monbod', 'monobj', 'animals', ...
    'humbod', 'humfac', 'humobj'};
param.carrStimNumPerCat = {[2 5 7 9 10 12 13 15 16 19], ...
    [1 3 4 5 6 8 10 11 13 17], ...
    [2 4 6 8 10 11 12 13 17 18], ...
    [2 3 4 5 10 12 17 18 19 20], ...
    [2 3 4 7 8 10 12 13 15 19], ...
    [3 4 5 10 13 15 16 17 18 20]};     % stim numbers for Category_EVEN
%   parameters for eye movements
param.startEyeM = -100; % param.start is defined in terms of f1 event
param.endEyeM = 200; % param.end is defined in terms of f2 event
% Parameters for spike analysis
param.spikeRateType = 0; % 1 = for Net Response, 0 = Total respone i.e. without using baseline.
param.Trials = 5; % number of trials to consider for avg. spike count per stimuli.
param.minTrials = 4; % minimum number of trials to consider in case of aborted generations.
param.startSpikeWin = +50; % param.startSpikeWin is defined in terms of f1 event
param.endSpikeWin = +50; % param.endSpikeWin is defined in terms of f2 event
param.startBaselineWin = -100; % param.startBaselineWin is defined in terms of f1 event,0 mean = f1
param.endBaselineWin = 0; % param.endBaselineWin is defined in terms of f1 event
% for PSTH
param.startPSTH = -100;
param.endPSTH = 400;
param.binsize = 10;
% LFP parameters
param.strChannel = 4;
param.bPerTrial = 1;
param.bPlot = 1;
param.iLFPmin = 2;    % -- range for the LFP amplitude
param.iLFPmax = 4093; % /
param.iLowFrq = 60;
param.iHighFrq  = 150;
param.iBaseline = 100; % [ms] before the start
param.structPath = ''; % path to save CSTRUCT file
param.LFPresutsDir = ''; % location of the LFP save dir
param.savepath = ''; % location of the save dir
% set the tickdirs to go out - need this specific order
set(groot, 'DefaultAxesTickDir', 'out');
set(groot, 'DefaultAxesTickDirMode', 'manual');

% general graphics.
set(groot, ...
    'DefaultFigureColorMap', linspecer, ...
    'DefaultFigureColor', 'w', ...
    'DefaultAxesLineWidth', 0.5, ...
    'DefaultAxesXColor', 'k', ...
    'DefaultAxesYColor', 'k', ...
    'DefaultAxesFontUnits', 'points', ...
    'DefaultAxesFontSize', 8, ...
    'DefaultAxesFontName', 'Helvetica', ...
    'DefaultLineLineWidth', 1, ...
    'DefaultTextFontUnits', 'Points', ...
    'DefaultTextFontSize', 8, ...
    'DefaultTextFontName', 'Helvetica', ...
    'DefaultAxesBox', 'off', ...
    'DefaultAxesTickLength', [0.02 0.025]);

% type cbrewer without input args to see all possible sets of colormaps
colors = cbrewer('qual', 'Set1', 10);

hIndx = figure;

%% Search test for 4AFC A0L2 Brain
param.CellIndex = {'BM67';'BM68';'BM69';'BM70';'BM71';'BM72'};
[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(2,5,1)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);

hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);

errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');

title(['A0L2:Brain MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Search test for 4AFC A0L2 Brain
param.CellIndex = {'BM67';'BM68';'BM69';'BM70';'BM71';'BM72'};

[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(2,5,1)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);

hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');

title(['A0L2:Brain MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)
%% Search test for 4AFC A0M1 Brain ALL sessions (control site)
param.CellIndex = {'BM51';'BM52';'BM53';'BM54';'BM73';'BM74';'BM76';'BM78'};

[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(2,5,3)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);

hold on;
errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');
title(['A0M1(control):Brain MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)


%% Search test for 4AFC A1M5 Gabbana ALL sessions
param.CellIndex = {'GMA82';'GMA83';'GMA84';'GMA85';'GMA86';'GMA87';'GMA88';...
    'GMA89';'GMA90'};

[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(2,5,5)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2);
hold on;
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);

errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');

title(['A1M5:Gabbana MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Search test for 4AFC P2M1 Gabbana ALL sessions(= sessions with microstimulation)
param.CellIndex = {'GMA120';'GMA121';'GMA122';'GMA123';'GMA124';'GMA125';'GMA126'};

[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(2,5,7)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2);
hold on;
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);

errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');

title(['P2M1(Control):Gabbana MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)

%% Search test for 4AFC A1M5 with 150 uA Gabbana ALL sessions
param.CellIndex = {'GMA80';'GMA81';'GMA82'};

[LFPresults, indx] = analyzeLFPGamma(param);
catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
LFP_gamma = [];
for i1 = 1:numel(indx)
    LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
end

subplot(2,5,9)
% animals
gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
gamma_anim = mean([gamma_anim, gamma_monbod], 2);
hold on;
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);

errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
% faces (humfac)
gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
hold on;
% objects (humobj & monobj)
gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
gamma_obj = mean([gamma_humobj gamma_monobj],2);
errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
hold on;
y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
b = bar([1, 2, 3],y,'FaceColor','flat');
b.CData = colors(1:3,:);
hold on;
axis tight;axis square;
max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
ylim([min_LFP max_LFP])
xlim([0 4]);
xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
box off;
[P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
[P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');

title(['A1M5(150uA):Gabbana MUA and LFP' 'N = ' num2str(numel(param.CellIndex))],'FontSize',8)
%% Search test for 4AFC A0M1 Brain
% param.CellIndex = {'BM51';'BM52';'BM53';'BM54'};
%% Search test for 4AFC A0M1 Brain with stimulation
% param.CellIndex = {'BM73';'BM74';'BM76';'BM78'};
%% Search test for 4AFC A0M1 Brain ALL sessions
% param.CellIndex = {'BM51';'BM52';'BM53';'BM54';'BM73';'BM74';'BM76';'BM78'};
%% Search test for 4AFC P2M1 Gabbana ALL sessions(= sessions with microstimulation)
% param.CellIndex = {'GMA120';'GMA121';'GMA122';'GMA123';'GMA124';'GMA125';'GMA126'};
