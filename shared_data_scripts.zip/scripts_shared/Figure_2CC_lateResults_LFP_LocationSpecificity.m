
%% Figure for 2AFC results
% parameters for file parsing (dataPreprocessing)
clear; close all;
%Add path
param.dropboxPath = '';% Specify path to working dir
param.carrCategory = {'monbod', 'monobj', 'animals', ...
    'humbod', 'humfac', 'humobj'};
param.carrStimNumPerCat = {[2 5 7 9 10 12 13 15 16 19], ...
    [1 3 4 5 6 8 10 11 13 17], ...
    [2 4 6 8 10 11 12 13 17 18], ...
    [2 3 4 5 10 12 17 18 19 20], ...
    [2 3 4 7 8 10 12 13 15 19], ...
    [3 4 5 10 13 15 16 17 18 20]};     % stim numbers for Category_EVEN
%   parameters for eye movements
param.startEyeM = -100; % param.start is defined in terms of f1 event
param.endEyeM = 200; % param.end is defined in terms of f2 event
% Parameters for spike analysis
param.spikeRateType = 0; % 1 = for Net Response, 0 = Total respone i.e. without using baseline.
param.Trials = 5; % number of trials to consider for avg. spike count per stimuli.
param.minTrials = 4; % minimum number of trials to consider in case of aborted generations.
param.startSpikeWin = +50; % param.startSpikeWin is defined in terms of f1 event
param.endSpikeWin = +50; % param.endSpikeWin is defined in terms of f2 event
param.startBaselineWin = -100; % param.startBaselineWin is defined in terms of f1 event,0 mean = f1
param.endBaselineWin = 0; % param.endBaselineWin is defined in terms of f1 event
% for PSTH
param.startPSTH = -100;
param.endPSTH = 400;
param.binsize = 10;
% LFP parameters
param.strChannel = 4;
param.bPerTrial = 1;
param.bPlot = 1;
param.iLFPmin = 2;    % -- range for the LFP amplitude
param.iLFPmax = 4093; % /
param.iLowFrq = 60;
param.iHighFrq  = 150;
param.iBaseline = 100; % [ms] before the start
param.structPath = ''; % path to save CSTRUCT file
param.LFPresutsDir = ''; % location of the LFP save dir
param.savepath = ''; % location of the save dir
% set the tickdirs to go out - need this specific order
set(groot, 'DefaultAxesTickDir', 'out');
set(groot, 'DefaultAxesTickDirMode', 'manual');

% general graphics.
set(groot, ...
    'DefaultFigureColorMap', linspecer, ...
    'DefaultFigureColor', 'w', ...
    'DefaultAxesLineWidth', 0.5, ...
    'DefaultAxesXColor', 'k', ...
    'DefaultAxesYColor', 'k', ...
    'DefaultAxesFontUnits', 'points', ...
    'DefaultAxesFontSize', 8, ...
    'DefaultAxesFontName', 'Helvetica', ...
    'DefaultLineLineWidth', 1, ...
    'DefaultTextFontUnits', 'Points', ...
    'DefaultTextFontSize', 8, ...
    'DefaultTextFontName', 'Helvetica', ...
    'DefaultAxesBox', 'off', ...
    'DefaultAxesTickLength', [0.02 0.025]);

% type cbrewer without input args to see all possible sets of colormaps
colors = cbrewer('qual', 'Set1', 10);

for rn = 1:5
    if rn == 1
        %%%% Gabbana 2AFC BodVsObjRev A1M5 reversed location of Bodies
        param.CellIndex = {'GS2BodVsObjRev01';'GS2BodVsObjRev02';'GS2BodVsObjRev03';'GS2BodVsObjRev04';...
            'GS2BodVsObjRev05'};
        monk = 'Gabbana';%'Brain';%
        test = 'Final';%'train';%
        pos =  'BodVsObjRev';%'BodVsObjRev';%'BodVsHouse';%'FaceVsObj';%'FaceVsHouse';%'BodVsFaces';%%'A0L2';%'A1M5';
        targetL = {'Animals','Objects'};%{'Animals';'HumanFaces';'Houses';'Objects'};
    elseif rn == 2
        %%%% Gabbana 2AFC BodVsHouse A0M4
        param.CellIndex = {'GS2BodVsObjRev_A0M4_01';'GS2BodVsObjRev_A0M4_02';'GS2BodVsObjRev_A0M4_03';'GS2BodVsObjRev_A0M4_04';...
            'GS2BodVsObjRev_A0M4_05'};
        monk = 'Gabbana';%'Brain';%
        test = 'Final';%'train';%
        pos =  'BodVsObjRev_A0M4';%'BodVsObjRev';%'BodVsHouse';%'FaceVsObj';%'FaceVsHouse';%'BodVsFaces';%%'A0L2';%'A1M5';
        targetL = {'Animals','Objects'};%{'Animals';'HumanFaces';'Houses';'Objects'};
    elseif rn == 3
        %%%% Gabbana 2AFC BodVsHouse P1M3
        param.CellIndex = {'GS2BodVsObjRev_P1M3_01';'GS2BodVsObjRev_P1M3_02';'GS2BodVsObjRev_P1M3_03';'GS2BodVsObjRev_P1M3_04'};
        monk = 'Gabbana';%'Brain';%
        test = 'Final';%'train';%
        pos =  'BodVsObjRev_P1M3';%'BodVsObjRev';%'BodVsHouse';%'FaceVsObj';%'FaceVsHouse';%'BodVsFaces';%%'A0L2';%'A1M5';
        targetL = {'Animals','Objects'};%{'Animals';'HumanFaces';'Houses';'Objects'};
    elseif rn == 4
        %%%% Gabbana 2AFC BodVsHouse P2M2
        param.CellIndex = {'GS2BodVsObjRev_P2M2_01';'GS2BodVsObjRev_P2M2_02';'GS2BodVsObjRev_P2M2_03';'GS2BodVsObjRev_P2M2_04'};
        monk = 'Gabbana';%'Brain';%
        test = 'Final';%'train';%
        pos =  'BodVsObjRev_P2M2';%'BodVsObjRev';%'BodVsHouse';%'FaceVsObj';%'FaceVsHouse';%'BodVsFaces';%%'A0L2';%'A1M5';
        targetL = {'Animals','Objects'};%{'Animals';'HumanFaces';'Houses';'Objects'};
    elseif rn == 5
        %%%% Gabbana 2AFC BodVsHouse P3M1
        param.CellIndex = {'GS2BodVsObjRev_P3M1_01';'GS2BodVsObjRev_P3M1_02';'GS2BodVsObjRev_P3M1_03'};
        monk = 'Gabbana';%'Brain';%
        test = 'Final';%'train';%
        pos =  'BodVsObjRev_P3M1';%'BodVsObjRev';%'BodVsHouse';%'FaceVsObj';%'FaceVsHouse';%'BodVsFaces';%%'A0L2';%'A1M5';
        targetL = {'Animals','Objects'};%{'Animals';'HumanFaces';'Houses';'Objects'};
    end
    
    markerstyles = {'o', '^'};
    addpath(genpath(fullfile(param.dropboxPath,'KU_Leuven','Prof_Rufin_Vogels','Scripts','spikes','causalityTests','behaviouralTests','psignifit-master','psignifit-master')));
    addpath(genpath(fullfile(param.dropboxPath,'toolboxes','Tools')));
    addpath(genpath(fullfile(param.dropboxPath,'toolboxes','gramm')));
    % set the tickdirs to go out - need this specific order
    set(groot, 'DefaultAxesTickDir', 'out');
    set(groot, 'DefaultAxesTickDirMode', 'manual');
    set(groot, ...
        'DefaultFigureColorMap', linspecer, ...
        'DefaultFigureColor', 'w', ...
        'DefaultAxesLineWidth', 0.5, ...
        'DefaultAxesXColor', 'k', ...
        'DefaultAxesYColor', 'k', ...
        'DefaultAxesFontUnits', 'points', ...
        'DefaultAxesFontSize', 8, ...
        'DefaultAxesFontName', 'Helvetica', ...
        'DefaultLineLineWidth', 1, ...
        'DefaultTextFontUnits', 'Points', ...
        'DefaultTextFontSize', 8, ...
        'DefaultTextFontName', 'Helvetica', ...
        'DefaultAxesBox', 'off', ...
        'DefaultAxesTickLength', [0.02 0.025]);
    
    % type cbrewer without input args to see all possible sets of colormaps
    colors = cbrewer('qual', 'Set1', 10);
    
    %% LFP plots
    %% Search test for 4AFC A0L2 Brain
    
    [LFPresults, indx] = analyzeLFPGamma(param);
    catNamesTarget = { 'animals','monbod','humbod','monobj','humobj','humfac',};
    LFP_gamma = [];
    for i1 = 1:numel(indx)
        LFP_gamma = [LFP_gamma; LFPresults(i1).gammaMean];
    end
    subplot(6,4,12 + rn)
    % animals
    gamma_anim = LFP_gamma(:,strcmp(catNamesTarget, 'animals'));
    gamma_monbod = LFP_gamma(:,strcmp(catNamesTarget, 'monbod'));
    gamma_anim = mean([gamma_anim, gamma_monbod], 2);
    % faces (humfac)
    gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
    gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj')); gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj')); gamma_obj = mean([gamma_humobj gamma_monobj],2);m_y = mean([gamma_anim gamma_humfac gamma_obj],2);
    
    hold on;
    errorbar(1,mean(gamma_anim), sem(gamma_anim - m_y),'Color',[0 0 0]);
    % faces (humfac)
    gamma_humfac = LFP_gamma(:,strcmp(catNamesTarget, 'humfac'));
    errorbar(2,mean(gamma_humfac), sem(gamma_humfac - m_y),'Color',[0 0 0]);
    hold on;
    % objects (humobj & monobj)
    gamma_humobj = LFP_gamma(:,strcmp(catNamesTarget, 'humobj'));
    gamma_monobj = LFP_gamma(:,strcmp(catNamesTarget, 'monobj'));
    gamma_obj = mean([gamma_humobj gamma_monobj],2);
    errorbar(3,mean(gamma_obj), sem(gamma_obj - m_y),'Color',[0 0 0]);
    hold on;
    y = [mean(gamma_anim); mean(gamma_humfac); mean(gamma_obj)];
    b = bar([1, 2, 3],y,'FaceColor','flat');
    b.CData = colors(1:3,:);
    hold on;
    axis tight;axis square;
    max_LFP = max([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) + 0.01 + max([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
    min_LFP = min([mean(gamma_anim), mean(gamma_humfac), mean(gamma_obj)]) - 0.01 - min([sem(gamma_anim - m_y), sem(gamma_humfac - m_y), sem(gamma_obj - m_y)]);
    ylim([min_LFP max_LFP])
    xlim([0 4]);
    xticks([1 2 3]);xticklabels({'animals','faces','objects'});xtickangle(45)
    box off;
    [P_ao,~]=ranksum(gamma_anim, gamma_obj, 'tail','right');
    [P_af,~]=ranksum(gamma_anim, gamma_humfac, 'tail','right');
    % [P_fo,~]=ranksum(gamma_humfac, gamma_obj, 'tail','right');
    % mysigstar(gca, [1 2], 0.2 + max([mean(gamma_anim), mean(gamma_humfac)]) , P_af);
    % mysigstar(gca, [1 3], 0.1 + max([mean(gamma_anim), mean(gamma_obj)]) , P_ao);
    % mysigstar(gca, [7 8], 0.1 + max([mean(gamma_humfac), mean(gamma_obj)]) , P_fo);
    title([pos '-' monk '-' test],'FontSize',8)
    %% Plotting the results
    if rn == 1
        aa1 = load(['dataP_',monk,'_',test,'_stim_categor_WithNoise_AllCells_50uA_',pos,'_ALL','.mat']);
        aa2 = load(['dataP_',monk,'_',test,'_stim_categor_WithNoise_AllCells_50uA_',pos,'04_ALL','.mat']);
        aa3 = load(['dataP_',monk,'_',test,'_stim_categor_WithNoise_AllCells_50uA_',pos,'05_06_ALL','.mat']);
        names = fieldnames(aa1);
        for i2 = 1:numel(names)
            combineddata.(names{i2})=[aa1.(names{i2})'; aa2.(names{i2})'; aa3.(names{i2})'];
        end
        for i2 = 1:numel(names)
            eval([names{i2} '= combineddata.(names{i2})'])
        end
    else
        load(['dataP_',monk,'_',test,'_stim_categor_WithNoise_AllCells_50uA_',pos,'_ALL','.mat']);
    end
    poolData = 1;
    nni = {'','Novel','Familiar'};
    
    noStim = {};withStim = {};noStimRT = {};withStimRT = {};
    n1 =1;
    iter = 1;
    for i1 = 1:numel(param.CellIndex)
        for i2 = 1:numel(dataP{1})
            noStim = [noStim; eval(['dataP{i1}{i2}.noStim',nni{n1}])];
            withStim = [withStim; eval(['dataP{i1}{i2}.withStim',nni{n1}])];
            noStimRT{iter} = eval(['dataP{i1}{i2}.noStimRT',nni{n1}]);
            withStimRT{iter} = eval(['dataP{i1}{i2}.withStimRT',nni{n1}]);
            iter = iter + 1;
        end
    end
    itr = 1;
    ut = numel(dataP{1});
    for t1 = 1:ut
        tt = noStim(t1:ut:numel(noStim));
        tmpDataP{1}{t1}.noStim =  sum(cat(3,tt{:}),3);
        tt2 = withStim(t1:ut:numel(withStim));
        tmpDataP{1}{t1}.withStim =  sum(cat(3,tt2{:}),3);
        tt3 = noStimRT(t1:ut:numel(noStimRT));
        %         ct3 = cat(3,tt3{:});
        %         [m1,n1]=size(tt3{1});
        
        tt4 = withStimRT(t1:ut:numel(withStimRT));
        
        for r1 = 1:numel(tt3{1}(1,:))
            dtt3t = {};dtt4t = {}; dtt3 = {};dtt4 = {};
            for c1 = 1:numel(tt4)
                dtt3t = [dtt3t; tt3{c1}(r1,:)];
                dtt4t = [dtt4t; tt4{c1}(r1,:)];
            end
            for n11 = 1:size(dtt3t,2)
                dtt3{n11} = [dtt3t{:,n11}];
                dtt4{n11} = [dtt4t{:,n11}];
            end
            tmpDataP{1}{t1}.noStimRT(r1,1:4) =  [nanmedian(dtt3{1}),nanmedian(dtt3{2}),nanmedian(dtt3{3}),nanmedian(dtt3{4})];
            tmpDataP{1}{t1}.withStimRT(r1,1:4) =  [nanmedian(dtt4{1}),nanmedian(dtt4{2}),nanmedian(dtt4{3}),nanmedian(dtt4{4})];
            tmpDataP{1}{t1}.noStimRTsem(r1,1:4) =  [sem(dtt3{1}),sem(dtt3{2}),sem(dtt3{3}),sem(dtt3{4})];
            tmpDataP{1}{t1}.withStimRTsem(r1,1:4) =  [sem(dtt4{1}),sem(dtt4{2}),sem(dtt4{3}),sem(dtt4{4})];
            if r1 == t1
                rtcorrect1{itr} = [dtt3{1}, dtt4{1}];
                rtcorrect2{itr} = [dtt3{2}, dtt4{2}];
                rtcorrect3{itr} = [dtt3{3}, dtt4{3}];
                rtcorrect4{itr} = [dtt3{4}, dtt4{4}];
                rtcorrect1nt{itr} = [dtt3{1}];
                rtcorrect2nt{itr} = [dtt3{2}];
                rtcorrect3nt{itr} = [dtt3{3}];
                rtcorrect4nt{itr} = [dtt3{4}];
                rtcorrect1wt{itr} = [dtt4{1}];
                rtcorrect2wt{itr} = [dtt4{2}];
                rtcorrect3wt{itr} = [dtt4{3}];
                rtcorrect4wt{itr} = [dtt4{4}];
                if ~isempty([dtt3{:},dtt4{:}])
                    maxRT(itr) = max([dtt3{:},dtt4{:}]);
                else
                    maxRT(itr) = 0;
                end
                itr = itr + 1;
            end
        end
    end
    dataPP = tmpDataP;
    uNoiseLvl = unique([stimul{1}(:).noiseLvl]);
    uTargets = numel(stimul{1}(1).targets);
    labels = {'Animals';'HumanFaces';'Houses';'Objects'};
    %% proportion of body signal
    %[x-value, number correct, number of trials]
    snr = fliplr(100 - uNoiseLvl);%% Set SNR levels used
    snrf = [-(snr(4)) -(snr(3)) -(snr(2)) -(snr(1)) snr(1) snr(2) snr(3) snr(4)]/100;
    clear dataPNS dataPWS
    it = 1;
    
    for p1 = [find(strcmp(targetL{1},labels)==1),find(strcmp(targetL{2},labels)==1)]
        for p2 = [find(strcmp(targetL{1},labels)==1)]%,find(strcmp(targetL{2},labels)==1)]
            dataColor = colors(p2,:);
            sm = sum(dataPP{1}{p1}.noStim);
            dataPNS{it}(:,2) = fliplr(dataPP{1}{p1}.noStim(p2,:));
            if it == 1
                dataPNS{it}(:,1) = snrf(5:end);
            else
                dataPNS{it}(:,1) = fliplr(snrf(1:4));
            end
            dataPNS{it}(:,3) = fliplr(sm);
            sm2 = sum(dataPP{1}{p1}.withStim);
            dataPWS{it}(:,2) = fliplr(dataPP{1}{p1}.withStim(p2,:));
            if it == 1
                dataPWS{it}(:,1) = snrf(5:end);
            else
                dataPWS{it}(:,1) = fliplr(snrf(1:4));
            end
            dataPWS{it}(:,3) = fliplr(sm2);
            it = it + 1;
            
        end
    end
    
    noStim = (cell2mat(dataPNS));
    withStim = (cell2mat(dataPWS));
    data = [flipud(noStim(:,1:3));noStim(:,4:6)];
    data2 = [flipud(withStim(:,1:3));withStim(:,4:6)];
    if ~isempty(strfind(param.CellIndex{1},'GS2BodVsObj0'))
        data(3,2) = 90;data2(3,2) = 53;data(4,2) = 40;data2(2,2) = 99;
    end
    if ~isempty(strfind(param.CellIndex{1},'BS2HouseVsObj0'))
        data(4,2) = 61;data2(4,2) = 51;
    end
    
  
    %%%%%%%%% Statistics on the fits %%%%%
    %% on pooled data for all sessions
    % parse data for percent shift calculation
    Ic = 0; ydNS = 0; ydS = 0;xdata = []; ydata = [];
    uV = unique(data(:,1));
    for i1 = 1:numel(uV)
        ind = find(uV(i1) == data(:,1));
        if numel(ind)>1
            dsum = sum(data(ind,2:end));
        else
            dsum = data(ind,2:end);
        end
        ydNS(i1) = dsum(1)/(dsum(2));
        Ic(i1) = 0;
        xdata(i1,:) = [Ic(i1), uV(i1)];
        ydata(i1,:) = ydNS(i1);
    end
    uV = unique(data2(:,1));
    for i1 = 1:numel(uV)
        ind = find(uV(i1) == data2(:,1));
        if numel(ind)>1
            dsum = sum(data2(ind,2:end));
        else
            dsum = data2(ind,2:end);
        end
        ydS(i1) = dsum(1)/(dsum(2));
        Ic(i1+8) = 1;
        xdata(i1+8,:) = [Ic(i1+8), uV(i1)];
        ydata(i1+8,:) = ydS(i1);
    end
    % Transpose if necessary
    if size(ydata,1)<size(ydata,2)
        ydata = ydata';
    end
    % Check range of data
    if min(ydata)<0 || max(ydata)>1
        % Normalise data to range 0 to 1
        ydata = (ydata-min(ydata)) / (max(ydata)-min(ydata));
    end
    % F = @(z) modelEquationPSlope( z, xdata, ydata );%%%Change in slope
    F = @(z) modelEquationP( z, xdata, ydata );%%% Shift in the curve
    
    lb = [-10 -10 -10]; ub = [10 10 10];
    z = [1 1 1];
    options = optimoptions('lsqnonlin','MaxFunEvals',length(z)*1000,'Algorithm','trust-region-reflective');
    problem = createOptimProblem('lsqnonlin','x0',[1 1 1],...
        'objective',F,'lb',lb,'ub',ub,...
        'options',options, 'xdata',xdata,'ydata',ydata);
    %'lb',lb,'ub',ub,...
    ms = MultiStart('UseParallel',false,'Display','iter','StartPointsToRun','bounds');
    % start points
    stpoints = RandomStartPointSet('NumStartPoints',100);%
    [x,errormulti] = run(ms,problem,stpoints);
    
    %     figure;
    if paramPlot == 1
        subplot(6,4,rn)
        h1 = plot(xdata(1:8,2),ydata(1:8),'bo');hold on;
        h2 = plot(xdata(9:16,2),ydata(9:16),'ro');
        set([h1(: )],  'color', colors(1, : ));
        set([h2(: )],  'color', colors(2, : ));
        set(h1(1), 'markersize', 4, 'marker', markerstyles{1}, 'markerfacecolor', 'w',...
            'markeredgecolor',colors(1+2, : )); % make the marker open
        set(h2(1), 'markersize', 4, 'marker', markerstyles{2}, 'markerfacecolor', 'w',...
            'markeredgecolor',colors(2+2, : )); % make the marker open
        tlist = linspace(-0.8,0.8);
        h3 = plot(tlist,(1./(1 + exp(-(x(1) + x(2)*tlist + x(3)*zeros(size(tlist)))))),'b-');
        h4 = plot(tlist,(1./(1 + exp(-(x(1) + x(2)*tlist + x(3)*ones(size(tlist)))))),'r-');
        set([h3(: )],  'color', colors(1, : ));
        set([h4(: )],  'color', colors(2, : ));
        % l = legend([h1 h2 h3 h4], {'A', 'B'});
        xlabel('Stimulus level')
        ylabel([targetL{1} ,' response'])
        ax = gca;ax.YLim = [0 1];
        axis tight; ax = gca;ax.YLim = [0 1];
        ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
    elseif paramPlot == 2
        subplot(6,4,rn)
        options             = struct;   % initialize as an empty struct
        options.nblocks        = 1; % number of blocks required to start pooling
        options.sigmoidName = 'logistic';   % choose a cumulative Gaussian as the sigmoid
        options.expType     = 'YesNo';%'equalAsymptote';%
        options.fixedPars = NaN(5,1);
        % options.fixedPars(3) = 0;
        % options.fixedPars(4) = 0;
        % options.fixedPars(5) = 0;% fixed the last parameter
        resultNS = psignifit(data,options);
        resultS = psignifit(data2,options);
        plotOptions.lineColor = colors(1, : );
        plotOptions.dataColor = colors(1,:);
        plotOptions.CIthresh       = false;
        plotOptions.yLabel         = [targetL{1} ,' response'];
        plotOptions.dataSize    = 5;
        plotOptions.plotThresh   = false;
        plotOptions.plotAsymptote  = false;
        [hline,hdata] = plotPsych(resultS,plotOptions);
        hold on
        plotOptions.lineColor = colors(2, : );
        plotOptions.dataColor = colors(2,:);
        [hline2,hdata2] = plotPsych(resultNS,plotOptions);
        %     legend([hline,hline2],'Fit Stim','Fit Non Stim')
        nNonStim = sum(data(:,3));
        nStim = sum(data2(:,3));
        %     title(['N(non stim) = ' num2str(nNonStim) ', N(stim) = ' num2str(nStim)]);
        hold off;
  
        xlabel('Stimulus level')
        ylabel([targetL{1} ,' response'])
        ax = gca;ax.YLim = [0 1];
        axis tight; ax = gca;ax.YLim = [0 1];
        ax.XLim = ([min(snrf)-0.1 max(snrf)+0.1]);axis square
    end
 
    results.fit = x;
    results.shift = x(3)/x(2);
    results.data = [xdata, ydata];
    % check significance of shift;
    for r1 = 1:1000
        % randomize the stim and non stim conditions
        clear datans datas
        for s1 = 1:numel(data(:,3))
            dnsb = data(s1,2);dnsnb = data(s1,3) - dnsb;
            dsb = data2(s1,2);dsnb = data2(s1,3) - dsb;
            nums = [zeros(dnsnb + dsnb, 1)' ones(dnsb+dsb,1)'];
            datans(s1,1:3) = data(s1,1:3);nn = randsample(nums, data(s1,3));
            datans(s1,2) = sum(nn);
            datas(s1,1:3) = data2(s1,1:3);nn2 = randsample(nums, data2(s1,3));
            datas(s1,2) = sum(nn2);
        end
        % parse data for percent shift calculation
        Ic = 0; ydNS = 0; ydS = 0;
        uV = unique(datans(:,1));
        for i1 = 1:numel(uV)
            ind = find(uV(i1) == datans(:,1));
            if numel(ind)>1
                dsum = sum(datans(ind,2:end));
            else
                dsum = datans(ind,2:end);
            end
            ydNS(i1) = dsum(1)/(dsum(2));
            Ic(i1) = 0;
            xdata(i1,:) = [Ic(i1), uV(i1)];
            ydata(i1,:) = ydNS(i1);
        end
        uV = unique(datas(:,1));
        for i1 = 1:numel(uV)
            ind = find(uV(i1) == datas(:,1));
            if numel(ind)>1
                dsum = sum(datas(ind,2:end));
            else
                dsum = datas(ind,2:end);
            end
            ydS(i1) = dsum(1)/(dsum(2));
            Ic(i1+8) = 1;
            xdata(i1+8,:) = [Ic(i1+8), uV(i1)];
            ydata(i1+8,:) = ydS(i1);
        end
        F = @(z) modelEquationP( z, xdata, ydata );%%% Shift in the curve
        lb = [-10 -10 -10]; ub = [10 10 10];
        z = [1 1 1];
        options = optimoptions('lsqnonlin','MaxFunEvals',length(z)*1000,'Algorithm','trust-region-reflective');
        problem = createOptimProblem('lsqnonlin','x0',[1 1 1],...
            'objective',F,'lb',lb,'ub',ub,...
            'options',options, 'xdata',xdata,'ydata',ydata);
        %'lb',lb,'ub',ub,...
        ms = MultiStart('UseParallel',true,'StartPointsToRun','bounds');
        % start points
        stpoints = RandomStartPointSet('NumStartPoints',100);%
        [x,errormulti] = run(ms,problem,stpoints);
        nullDistShift(r1) = x(3)/x(2);
        r1
    end
    results.nullDistShift = nullDistShift;clear nullDistShift
    results.shiftPval = sum(results.nullDistShift>results.shift)/numel(results.nullDistShift);
    title([pos ',T=' num2str(sum([sum(data(:,3)) sum(data2(:,3))])) , ',S=' num2str(results.shift),',p=' num2str(results.shiftPval)])
    save(['percentShiftStat_', param.CellIndex{1}],'results')
    pos
    %%%%%%%%
end
savefig('2AFC_lateResults_shift_LocationSpecificity');