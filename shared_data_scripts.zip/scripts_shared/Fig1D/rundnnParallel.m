function [data2] = rundnnParallel(X,y, f1)
        indxn = 1:numel(y);
        in = f1:5:numel(y);
        data(f1).featuresTest = X(in,:);
        data(f1).YTest = y(in);
        data(f1).featuresTrain = X(setdiff(indxn,in),:);
        data(f1).YTrain = y(setdiff(indxn,in));
        classifier = fitcecoc(data(f1).featuresTrain,data(f1).YTrain);
        data(f1).YPred = predict(classifier,data(f1).featuresTest);
        
        %% calculate the accuracy
        data(f1).accuracy = mean(data(f1).YPred == data(f1).YTest);
        data2 = data(f1);
end

