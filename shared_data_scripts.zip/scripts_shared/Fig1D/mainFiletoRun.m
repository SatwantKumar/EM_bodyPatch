%%% DNN Low level feature control
%% convert the input image to 4deg resize
clear; close all;
labels = {'animate','houses','housesObjects','humanFaces'};
% noise_lvls = [0 20,40,80,95];
noise_lvls = 60; % specify noie level of the images to use
path_to_root_dir = ''; % specify the path to images
for ns = 1:numel(noise_lvls)
    for c1 = 1:numel(labels)
        pathN = fullfile(path_to_root_dir,'\imgData',labels{c1});
        pathW = fullfile(path_to_root_dir, ['imgDataNoise_', num2str(noise_lvls(ns))], labels{c1});
        if exist(pathW,'dir')== 0
            mkdir(pathW)
        end
        filesN = dir(fullfile([pathN,'\*.bmp']));
        for i1 = 1:numel(filesN)
            pathR = fullfile(pathN, filesN(i1).name);
            I = imread(pathR);
            I = imnoise((I),'salt & pepper',noise_lvls(ns)/100);
            I = cat(3, I,I,I);
        
            pathWR = fullfile(pathW,filesN(i1).name);
            imwrite(imresize(I,2), pathWR)
        end
    end
end
%% load data
clear; close all;
labels = {'animate','houses','housesObjects','humanFaces'};
noise_lvls = [0 20,40,80,95];
% noise_lvls = [60];
%% Load pre-trained network
net = alexnet;
net.Layers
inputSize = net.Layers(1).InputSize;
datasem = zeros(1, numel(noise_lvls));
for ns = 1:numel(noise_lvls)
    imds = imageDatastore(['imgDataNoise_', num2str(noise_lvls(ns))],...
        'IncludeSubfolders',true,...
        'LabelSource','foldernames');
   
    %% extract image features
    augimds = augmentedImageDatastore(inputSize(1:2),imds);
    
    layer = 'conv1';
    X = activations(net,augimds,layer,'OutputAs','rows');
    y = imds.Labels;
    
    indxFaces = find(y=='humanFaces');
    indxHouses = find(y=='houses');
    indxObjects = find(y=='housesObjects');
    indxAnim = find(y=='animate');
    minN = min([numel(indxFaces),numel(indxHouses),numel(indxObjects),numel(indxAnim)]);
    indF = [randsample(indxFaces,minN);randsample(indxHouses,minN);randsample(indxObjects,minN);randsample(indxAnim,minN)];
    X = X(indF,:); y = y(indF);
    clear data
    %% Fit the classifier
    parfor f1 = 1:5
        [data(f1)] = rundnnParallel(X,y, f1);
    end
    datasem(ns) = std([data(:).accuracy])./sqrt(5);
    h = plotconfusion([data(1).YTest;data(2).YTest;data(3).YTest;data(4).YTest;data(5).YTest], [data(1).YPred;data(2).YPred;data(3).YPred;data(4).YPred;data(5).YPred]);
    savefig(h,['confusionMatrixImgDataNoise_', num2str(noise_lvls(ns)),'_',layer])
end
%% plot percent correct for each noise level
figure;
subplot(4,3,1)
dataColor = [0.5 0.5 0.5];
dp2 = [64.2, 55.3, 48.4, 39.4, 28.4, 25.7];
uNoiseLvl = [0 20 40 60 80 95]; % Noise levels
sm2 = 109*4;
pp = dp2./100;
err = 1.96*(sqrt((pp.*(1-pp))./sm2));
plot(fliplr(100 - uNoiseLvl),fliplr(dp2),'-o', 'Color',dataColor)

ylim([0 100])
xlim([min(100 - uNoiseLvl)-10 max(100 - uNoiseLvl)+10]);
hold on;
ax = gca;
ax.XTick = fliplr(100 - uNoiseLvl);
axis square
xlabel('SNR level (%)')
ylabel('Correct response (%)')